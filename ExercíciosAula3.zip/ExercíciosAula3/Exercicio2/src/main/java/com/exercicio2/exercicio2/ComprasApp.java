package com.exercicio2.exercicio2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;


import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.*;
import android.view.*;
import android.app.*;
public class ComprasApp extends Activity {


    CheckBox androidact,gandroid,usehead,devapp,design;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        androidact = (CheckBox) findViewById(R.id.androidact);
        gandroid = (CheckBox) findViewById(R.id.gandroid);
        usehead = (CheckBox) findViewById(R.id.usehead);
        devapp = (CheckBox) findViewById(R.id.devapp);
        design = (CheckBox) findViewById(R.id.design);

        Button bttotal = (Button) findViewById(R.id.bttotal);

        bttotal.setOnClickListener(new View.OnClickListener(){

            public void onClick(View arg0) {

            double total =0;

            if(androidact.isChecked())
                total += 70.69;

            if(gandroid.isChecked())
                total += 180.00;
            if(usehead.isChecked())
                total += 100.00;

            if(devapp.isChecked())
                total += 80.30;

            if(design.isChecked())
                    total += 66.00;


            AlertDialog.Builder dialogo = new AlertDialog.Builder(ComprasApp.this);
            dialogo.setTitle("Aviso");
            dialogo.setMessage("Valor total da compra :" + String.valueOf(total));
            dialogo.setNeutralButton("OK", null);
            dialogo.show();

        }

        });

    }
}